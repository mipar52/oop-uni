﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace zadatak02.Model
{
    internal class Osoba
    {
        private const char delimiter = '|';

        public int Id { get; set; }
        public string Ime { get; set; }
        public string Prezime { get; set; }

        public Osoba(int id, string ime, string prezime)
        {
            Id = id;
            Ime = ime;
            Prezime = prezime;
        }

        public override string ToString() => $"{Id} {Ime} {Prezime}";
        public string Format() => $"{Id}{delimiter}{Ime}{delimiter}{Prezime}";
        public static Osoba Parse(string line)
        {
            string[] userInfos = line.Split(delimiter);
            return new Osoba(int.Parse(userInfos[0]), userInfos[1], userInfos[2]);
        }
    }
}
