﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace zadatak02
{
    internal class Program
    {
        static void Main(string[] args)
        {
            IRepository repo = RepositoryFactory.GetRepository();
            repo.Insert(new Model.Osoba(1, "Mato", "Matic"));
            repo.Insert(new Model.Osoba(2, "Pero", "Matic"));
            repo.Insert(new Model.Osoba(3, "Marina", "Peric"));
           
            ISet<Model.Osoba> osobe = repo.GetOsobe();
            osobe.ToList().ForEach(o => {Console.WriteLine(o.ToString());});
        }
    }
}
