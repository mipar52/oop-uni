﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using zadatak02.Model;

namespace zadatak02
{
    internal interface IRepository
    {
        void Insert(Osoba osoba);
        ISet<Osoba> GetOsobe();
    }
}
