﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using zadatak02.Model;

namespace zadatak02
{
    internal class FileRepository : IRepository
    {
        private const string documentPath = @"C:\Users\Student\Desktop\osobe.txt.txt"; 

        public void Insert(Osoba osoba)
        {
            ISet<Osoba> osobe = GetOsobe();
            osobe.Add(osoba);
            File.WriteAllLines(documentPath, osobe.Select(x => x.Format()));
        }

        public ISet<Osoba> GetOsobe()
        {
            ISet<Osoba> osobe = new HashSet<Osoba>();
            string[] lines = File.ReadAllLines(documentPath);
            lines.ToList().ForEach(line => osobe.Add(Osoba.Parse(line)));
            return osobe;
        }
    }
}
