﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace zadatak01
{
    internal class Program
    {
        static void Main(string[] args)
        {
            string username = "mato123";
            string password = "1234";
            // password = "123456" -> ispravna lozinka
            try
            {
                Callee(username, password);

            }
            catch (PasswordTooShortException e) 
            { 
                Console.WriteLine($"Autentifikacija neupješna! Razlog:\n{e.Message}");
                Console.WriteLine();
                // additional exception info
                Console.WriteLine(e.GetType().FullName);
                Console.WriteLine(e.StackTrace.ToString());
                
            }
        }

        private static void Callee(string username, string password)
        {
            if (password.Length < 6)
            {
                throw new PasswordTooShortException($"Lozinka je kratka! Mora imati minimalno 6 znakova, a unesena ima: {password.Length}");
            }

            Console.WriteLine($"Autentikacija uspješna!\nKorisničko ime: {username}, Lozinka: {password}");
        }
    }
}
