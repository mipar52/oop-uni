﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace zadatak01
{
    internal class PasswordTooShortException: Exception
    {
        public string customMessage {  get; set; }
        public PasswordTooShortException(string message): base() 
        { 
            this.customMessage = message;
        }

        public override string Message => customMessage;
    }
}
