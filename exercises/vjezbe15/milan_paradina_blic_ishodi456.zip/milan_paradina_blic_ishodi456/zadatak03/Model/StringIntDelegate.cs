﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace zadatak03.Model
{
    public delegate int StringArrivedDelegate(object sender, StringIntEventArgs args);
}
