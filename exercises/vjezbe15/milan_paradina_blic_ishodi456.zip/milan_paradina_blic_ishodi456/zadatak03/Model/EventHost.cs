﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace zadatak03.Model
{
    class EventHost
    {
        public event StringArrivedDelegate OnStringArrived;

        public void StringHasArrived(string arrivedString) => OnStringArrived?.Invoke(this, new StringIntEventArgs { arrivedString = arrivedString });
    }
}
