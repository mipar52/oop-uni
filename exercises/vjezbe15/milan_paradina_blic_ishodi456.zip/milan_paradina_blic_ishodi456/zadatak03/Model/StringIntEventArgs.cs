﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace zadatak03.Model
{
    public class StringIntEventArgs : EventArgs
    {
        public string arrivedString { get; set; }
    }
}
