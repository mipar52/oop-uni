﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using zadatak03.Model;

namespace zadatak03
{
    internal class Program
    {
        static void Main(string[] args)
        {
            EventHost host = new EventHost();
            host.OnStringArrived += EnterStringOf;            

            while (true)
            {
                host.StringHasArrived("Garflid mackovic");
                Thread.Sleep(1000);
                host.StringHasArrived("Zadatak 3: Definirajte delegat koji prima string i vraca int");
                Thread.Sleep(1000);
            }
        }

        private static int EnterStringOf(object sender, StringIntEventArgs args)
        {
            Console.ForegroundColor = ConsoleColor.Green;
            Console.WriteLine($"Got a new String: {args.arrivedString}, Lenght: {args.arrivedString.Length}");
            int numOfA = 0;

            for (int i = 0; i< args.arrivedString.Length; i++)
            {
                if (args.arrivedString[i] == 'a') { numOfA++; }
            }
            Console.ForegroundColor = ConsoleColor.Magenta;
            Console.WriteLine($"Number of a characters: {numOfA}");
            return numOfA;
        }
    }
}
