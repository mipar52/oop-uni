﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Zadatak1
{
    internal class Auto
    {
        public int BrojAuta {  get; private set; }
        public string Ime { get; set; }
        public double Cijena { get; set; }
        public double kilometraza { get; set; }

        public Auto(int brojAuta, string ime, double cijena, double kilometraza)
        {
            if (this.provjeriBroj(brojAuta))
            {
                BrojAuta = brojAuta;
            } else
            {
                throw new Exception($"Neispravan broj auta!!!\nBroj mora sadrzavati 5 brojeva, a unesi broj ima {brojAuta.ToString().Length}");
            }
            Ime = ime;
            Cijena = cijena;
            this.kilometraza = kilometraza;
        }

        public Auto(int brojAuta) 
        { 
            if(this.provjeriBroj(brojAuta))
            {
                BrojAuta = brojAuta;
            } else
            {
                throw new Exception($"Neispravan broj auta!!!\nBroj mora sadrzavati 5 brojeva, a unesi broj ima {brojAuta.ToString().Length}");
            }
        }

        public override string ToString() => $"Broj auta: {this.BrojAuta}\nIme: {this.Ime}\nCijena: {this.Cijena}\nKilometraza: {this.kilometraza}\n";
        private bool provjeriBroj(int brojAuta) => brojAuta.ToString().Length == 5;
    }
}
