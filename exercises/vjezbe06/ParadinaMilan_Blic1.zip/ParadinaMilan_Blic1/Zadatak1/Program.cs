﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Zadatak1
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Auto auto1 = new Auto(12345, "Peugeot", 3500.50, 100000.34);
            Console.WriteLine(auto1.ToString());

            Auto auto2 = new Auto(56789);
            Console.WriteLine(auto2.ToString());

            auto1.Cijena = 4000.10;
            auto1.Ime = "Fiat";
            auto1.kilometraza = 35000;
            Console.WriteLine(auto1.ToString());

            auto2.Ime = "Laborghini";
            auto2.Cijena = 3000;
            auto2.kilometraza = 450000;
            Console.WriteLine(auto2.ToString());

          /* sljedece dvije linije uzrokuju exception radi neispravnog unosa broja */
            Auto neispravnoAuto1 = new Auto(1234);
          //  Auto neispravnoAuto2 = new Auto(123, "Renault", 1004000, 3000000);
        }
    }
}
