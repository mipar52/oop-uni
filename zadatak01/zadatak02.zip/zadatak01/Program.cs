﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

// 1. Napišite „HelloWorld” program u jeziku C#.
namespace zadatak01 
{
    internal class Program // 
    {
        static void Main(string[] args)
        {
            Console.Write("Hello, world!"); // Console je dio System librarya
            Console.WriteLine("Hello, world!"); //ispise i ide u novu liniju odmah

        }
    }
}
